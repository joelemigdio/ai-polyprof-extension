//#region src/services/polyratings-api.ts
var e = "https://api-prod.polyratings.org", t = `${e}/professors.all`;
function n(t) {
	return `${e}/professors.get?input=${encodeURIComponent(JSON.stringify({ id: t }))}`;
}
function r(e) {
	let t = e;
	if (t.error) throw Error(t.error.message ?? "PolyRatings request failed");
	if (t.result?.data === void 0) throw Error("PolyRatings response had no data");
	return t.result.data;
}
//#endregion
//#region src/background/service-worker.ts
var i = 864e5, a = "polyratingsIndex";
async function o(e) {
	let t = await fetch(e, { headers: { Accept: "application/json" } });
	if (!t.ok) throw Error(`PolyRatings responded ${t.status}`);
	return t.json();
}
async function s() {
	let e = (await chrome.storage.local.get(a))[a];
	if (e && Date.now() - e.fetchedAt < i) return e.professors;
	try {
		let e = r(await o(t));
		return await chrome.storage.local.set({ [a]: {
			fetchedAt: Date.now(),
			professors: e
		} }), e;
	} catch (t) {
		if (e) return e.professors;
		throw t;
	}
}
async function c(e) {
	let t = `polyratingsProfessor:${e}`, i = (await chrome.storage.session.get(t))[t];
	if (i) return i;
	let a = r(await o(n(e)));
	return await chrome.storage.session.set({ [t]: a }), a;
}
async function l(e) {
	return e.type === "professorIndex" ? s() : c(e.id);
}
chrome.runtime.onMessage.addListener((e, t, n) => (l(e).then((e) => n({
	ok: !0,
	data: e
})).catch((e) => n({
	ok: !1,
	error: e instanceof Error ? e.message : String(e)
})), !0));
//#endregion
